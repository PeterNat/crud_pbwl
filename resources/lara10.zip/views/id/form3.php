<?php
return 
[
	'title' => 'tambah peminjaman',
	'input' => ['tgl_pinjam'    => 'Tanggal Pinjam',
				'id_anggota'  => 'ID Anggota',
				'id_buku' => 'ID Buku',
			'lama_pinjam' => 'Lama Pinjam',
				'tombol1'  => 'Simpan',
				'tombol2'  => 'Batal',
			   ]
];