@extends('master') 
@section('title', 'Data Buku') 

@section('content')
<div class="container mt-3">
  <h2>Data Buku</h2>  
  <p><a href="/createbuku">
  <button class="btn btn-success mb-2">Tambah Buku</button></a></p>  

  <table class="table table-bordered table-striped">
    <thead class="table-success">
      <tr style="text-align:center">
        <th>Id</th>
        <th>Judul</th>
	    <th>Penulis</th>
		<th>Penerbit</th>
		<th>Kode Kategori</th>		
		<th>Harga Buku</th>
		<th>Edit</th>
		<th>Hapus</th>
		</tr>
	</thead> 

    <tbody>
	@foreach ($data_buku as $buku)
      <tr>
	    <td style="text-align:center">{{$buku->id}}</td>
        <td>{{$buku->judul}}</td>
		<td>{{$buku->penulis}}</td>	
		<td>{{$buku->penerbit}}</td>   			  
		<td style="text-align:center">{{$buku->kodekategori}}</td>	
		<td style="text-align:right">{{number_format($buku->hargabuku)}}</td>		
        <td style="text-align:center"><a href="{{route('ubahbuku', $buku->id)}}">
			<button class="btn btn-primary btn-sm">Edit</button></a></td>
		<td style="text-align:center">
		    <form action="{{route('hapusbuku', $buku->id)}}" method="post">
		       @csrf
			   <button class="btn btn-primary btn-sm" 
			           onClick="return confirm('Yakin mau dihapus?')">Hapus</button>
			</form></td>  				
      </tr>
	@endforeach  
	</tbody>
  </table>
</div>  
@endsection

