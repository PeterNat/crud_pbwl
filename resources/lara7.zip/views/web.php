<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ModelController;

Route::get('/', [ModelController::class,'welcome']);

Route::get('/buku', [ModelController::class,'buku']);
Route::get('/createbuku', [ModelController::class,'createbuku']);
Route::post('/savebuku', [ModelController::class,'savebuku']);
Route::post('/delbuku/{id}', [ModelController::class,'delbuku'])
->name('hapusbuku');
Route::get('/editbuku/{id}', [ModelController::class,'editbuku'])
->name('ubahbuku');
Route::post('/updatebuku/{id}', [ModelController::class,'updatebuku'])
->name('modifbuku');

Route::get('/anggota', [ModelController::class,'anggota']);
Route::get('/createanggota', [ModelController::class,'createanggota']);
Route::post('/saveanggota', [ModelController::class,'saveanggota']);
Route::post('/delanggota/{id}', [ModelController::class,'delanggota'])
->name('hapusanggota');
Route::get('/editanggota/{id}', [ModelController::class,'editanggota'])
->name('ubahanggota');
Route::post('/updateanggota/{id}', [ModelController::class,'updateanggota'])
->name('modifanggota');

Route::get('/peminjaman', [ModelController::class,'peminjaman']);
Route::get('/createpeminjaman', [ModelController::class,'createpeminjaman']);
Route::post('/savepeminjaman', [ModelController::class,'savepeminjaman']);
Route::post('/delpeminjaman/{id}', [ModelController::class,'delpeminjaman'])
->name('hapuspeminjaman');
Route::get('/editpeminjaman/{id}', [ModelController::class,'editpeminjaman'])
->name('ubahpeminjaman');
Route::post('/updatepeminjaman/{id}', [ModelController::class,'updatepeminjaman'])
->name('modifpeminjaman');