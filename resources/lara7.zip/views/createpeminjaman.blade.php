@extends('master')
@section('title', 'Tambah peminjaman')

@section('content')
<div class="container mb-3 mt-3">
  <h2>Tambah Data Peminjaman</h2>
  <form method="post" action="/savepeminjaman">
     @csrf
	  <div class="mb-3 mt-3">
		<label for="tgl_pinjam" class="form-label">Tanggal Pinjam :</label>
		<input type="date" class="form-control" id="tgl_pinjam" name="tgl_pinjam">
	  </div>
	  <div class="mb-3 mt-3">
		<label for="id-anggota" class="form-label">Id Anggota :</label>
		<input type="text" class="form-control" id="id_anggota" name="id_anggota">
	  </div>
 	  <div class="mb-3 mt-3">
		<label for="id_buku" class="form-label">Id Buku :</label>
		<input type="text" class="form-control" id="id_buku" name="id_buku">
	  </div>
	  <div class="mb-3 mt-3">
		<label for="lama_pinjam" class="form-label">Lama Pinjam :</label>
		<input type="text" class="form-control" id="lama_pinjam" name="lama_pinjam">
	  </div>
      <div class="mb-3 mt-3">
	    <button class="btn btn-success mb-2" type="submit">Simpan</button>
        <button class="btn btn-success mb-2" type="reset">Batal</button>
      </div>
  </form>
</div>
@endsection

