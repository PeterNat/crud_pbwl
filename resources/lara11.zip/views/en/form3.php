<?php
return 
[
	'title' => 'Insert Loaning',
	'input' => ['tgl_pinjam'    => 'loan Date',
				'id_anggota'  => 'Member ID',
				'id_buku' => 'Book ID',
			'lama_pinjam' => 'Length of Loan',
				'tombol1'  => 'Save',
				'tombol2'  => 'Cancel',
			   ]
];