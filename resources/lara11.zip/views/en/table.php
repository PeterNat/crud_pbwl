<?php
return 
[
	'title' => 'Book data',
	'column' => ['judul'    => 'Title',
				'penulis'  => 'Writer',
				'penerbit' => 'Author',
				'kategori' => 'Category',
				'harga' => 'Price',
				'edit'  => 'Edit',
				'hapus'  => 'Delete',
				'tombol3'  => 'Add Book',
				'alert_hapus'  => 'Are you sure to delete?',
			   ]
];