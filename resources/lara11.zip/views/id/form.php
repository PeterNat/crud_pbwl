<?php
return 
[
	'title' => 'Tambah Buku',
    'input' => ['judul'    => 'Judul Buku',
				'penulis'  => 'Penulis',
				'penerbit' => 'Penerbit',
				'kategori' => 'Kategori',
				'pilihan_kategori' => 
				  ['sains' => 'Sains',
				   'fiksi' => 'Fiksi',
				  ],
				'harga'    => 'Harga Buku',
				'tombol1'  => 'Simpan',
				'tombol2'  => 'Batal',				
			   ]
];