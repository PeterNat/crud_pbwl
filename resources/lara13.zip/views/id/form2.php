<?php
return 
[
	'title' => 'Tambah Anggota',
    'input' => ['npm'    => 'NPM',
				'nama'  => 'nama',
				'gender' => 'Gender',
				'pilihan_gender' => 
				['laki' => 'Laki-laki',
				'perempuan' => 'Perempuan',
			],
			'alamat' => 'Alamat',
				'tombol1'  => 'Simpan',
				'tombol2'  => 'Batal',				
			   ]
];