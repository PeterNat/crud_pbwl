<?php
return 
[
	'title' => 'Insert Member',
	'input' => ['npm'    => 'NPM',
				'nama'  => 'Name',
				'gender' => 'Gender',
				'pilihan_gender' => 
				['laki' => 'Male',
				'perempuan' => 'Female',
			],
			'alamat' => 'Address',
				'tombol1'  => 'Save',
				'tombol2'  => 'Cancel',
			   ]
];