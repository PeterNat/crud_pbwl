<?php
return 
[
	'title' => 'Data Buku',
	'column' => ['judul'    => 'Judul',
				'penulis'  => 'Penulis',
				'penerbit' => 'Penerbit',
				'kategori' => 'kategori',
				'harga' => 'harga Buku',
				'edit'  => 'Edit',
				'hapus'  => 'hapus',
				'tombol3'  => 'tambah Buku',
				'alert_hapus'  => 'Apakah kamu yakin mau dihapus?',
			   ]
];