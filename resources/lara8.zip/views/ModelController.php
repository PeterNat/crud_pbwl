<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Buku;
use App\Models\Anggota;
use App\Models\Peminjaman;

class ModelController extends Controller
{
	public function welcome(){
	return view('welcome');}

	public function buku(){
	$data_buku = Buku::all();
	return view('buku', compact('data_buku'));}

	public function createbuku(){
	return view('createbuku');}
	 
	public function savebuku(Request $req){
    $this->validate($req,[
	  'judul' => 'required|string',
	  'penulis' => 'required|string',
	  'penerbit' => 'required|string', 
	  'harga' => 'required|gt:0']); 	
	$buku = new Buku;
	$buku->judul = $req->judul;
	$buku->penulis = $req->penulis;
	$buku->penerbit = $req->penerbit;
	$buku->kodekategori = $req->kodekat;
	$buku->hargabuku = $req->harga;
	$buku->save();
	return redirect('/buku')->with('pesan','Data buku berhasil disimpan');}
	
	public function delbuku($id){
	$buku = Buku::find($id);
	$buku->delete();
    return redirect('/buku')->with('pesan','Data anggota berhasil dihapus');}

	public function editbuku($id){
	$buku = Buku::find($id);
	return view('editbuku', compact('buku'));}

	public function updatebuku(Request $req, $id){
    $this->validate($req,[
	  'judul' => 'required|string',
	  'penulis' => 'required|string',
	  'penerbit' => 'required|string', 
	  'harga' => 'required|gt:0']); 		
	$buku = Buku::find($id);
	$buku->judul = $req->judul;
	$buku->penulis = $req->penulis;
	$buku->penerbit = $req->penerbit;
	$buku->kodekategori = $req->kodekat;
	$buku->hargabuku = $req->harga;
	$buku->update();
	return redirect('/buku')->with('pesan','Data buku berhasil diubah');}
		
	public function anggota(){
	$data_anggota = ANGGOTA::all();
	return view('anggota', compact('data_anggota'));}
	
	public function createanggota(){
	return view('createanggota');}	
	
	public function saveanggota(Request $req){
		$this->validate($req,[
			'npm' => 'required',
			'nama' => 'required|string',
			'kodegender' => 'required|string', 
			'alamat' => 'required|string']); 	
	$anggota = new Anggota;
	$anggota->npm = $req->npm;
	$anggota->nama = $req->nama;
	$anggota->kodegender = $req->kodegen;
	$anggota->alamat = $req->alamat;
	$anggota->save();
	return redirect('/anggota')->with('pesan','Data buku berhasil disimpan');}
	
	public function delanggota($id){
	$anggota = Anggota::find($id);
	$anggota->delete();
	return redirect('/anggota')->with('pesan','Data anggota berhasil dihapus');}
	
	public function editanggota($id){
	$anggota = Anggota::find($id);
	return view('editanggota', compact('anggota'));}

	public function updateanggota(Request $req, $id){
		$this->validate($req,[
			'npm' => 'required|string',
			'nama' => 'required|string',
			'kodegender' => 'required|string', 
			'alamat' => 'required|string']); 		
	$anggota = Anggota::find($id);
	$anggota->npm = $req->npm;
	$anggota->nama = $req->nama;
	$anggota->kodegender = $req->kodegen;
	$anggota->alamat = $req->alamat;
	$anggota->update();
	return redirect('/anggota')->with('pesan','Data buku berhasil diubah');}

	public function peminjaman(){
	$data_peminjaman = PEMINJAMAN::all();
	return view('peminjaman', compact('data_peminjaman'));}
	
	public function createpeminjaman(){
	return view('createpeminjaman');}	
	
	public function savepeminjaman(Request $req){
		$this->validate($req,[
			'tgl_pinjam' => 'required|date',
			'id_anggota' => 'required|string',
			'id_buku' => 'required|string', 
			'lama_pinjam' => 'required|gt:0']); 	
	$peminjaman = new peminjaman;
	$peminjaman->tgl_pinjam = $req->tgl_pinjam;
	$peminjaman->id_anggota = $req->id_anggota;
	$peminjaman->id_buku = $req->id_buku;
	$peminjaman->lama_pinjam = $req->lama_pinjam;
	$peminjaman->save();
	return redirect('/peminjaman')->with('pesan','Data buku berhasil disimpan');}
	
	public function delpeminjaman($id){
	$peminjaman = Peminjaman::find($id);
	$peminjaman->delete();
	return redirect('/peminjaman')->with('pesan','Data anggota berhasil dihapus');}
	
	public function editpeminjaman($id){
	$peminjaman = Peminjaman::find($id);
	return view('editpeminjaman', compact('peminjaman'));}

	public function updatepeminjaman(Request $req, $id){
		$this->validate($req,[
			'tgl_pinjam' => 'required|date',
			'id_anggota' => 'required|string',
			'id_buku' => 'required|string', 
			'lama_pinjam' => 'required|gt:0']); 	
	$peminjaman = Peminjaman::find($id);
	$peminjaman->tgl_pinjam= $req->tgl_pinjam;
	$peminjaman->id_buku = $req->id_buku;
	$peminjaman->id_anggota = $req->id_anggota;
	$peminjaman->lama_pinjam = $req->lama_pinjam;
	$peminjaman->update();
	return redirect('/peminjaman')->with('pesan','Data buku berhasil diubah');}
}
