<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ModelController;

Route::get('/', [ModelController::class,'welcome']);

Route::get('/buku', [ModelController::class,'buku']);
Route::get('/createbuku', [ModelController::class,'createbuku']);
Route::post('/savebuku', [ModelController::class,'savebuku']);
Route::post('/delbuku/{id}', [ModelController::class,'delbuku'])
->name('hapusbuku');
Route::get('/editbuku/{id}', [ModelController::class,'editbuku'])
->name('ubahbuku');
Route::post('/updatebuku/{id}', [ModelController::class,'updatebuku'])
->name('modifbuku');

Route::get('/anggota', [ModelController::class,'anggota']);
Route::get('/createanggota', [ModelController::class,'createanggota']);
Route::post('/saveanggota', [ModelController::class,'saveanggota']);
Route::get('/peminjaman', [ModelController::class,'peminjaman']);
Route::post('/delanggota/{id}', [ModelController::class,'delanggota'])
->name('hapusanggota');
Route::get('/editanggota/{id}', [ModelController::class,'editanggota'])
->name('ubahanggota');
Route::post('/updateanggota/{id}', [ModelController::class,'updateanggota'])
->name('modifanggota');