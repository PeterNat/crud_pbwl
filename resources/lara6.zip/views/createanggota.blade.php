@extends('master') 
@section('title', 'Tambah Anggota') 

@section('content')
<div class="container mb-3 mt-3">
  <h2>Tambah Data Anggota</h2>  
  <form method="post" action="/saveanggota">
     @csrf
	  <div class="mb-3 mt-3">
		<label for="npm" class="form-label">NPM :</label>
		<input type="text" class="form-control" id="npm" name="npm">
	  </div>  
	  <div class="mb-3 mt-3">
		<label for="nama" class="form-label">Nama Anggota :</label>
		<input type="text" class="form-control" id="nama" name="nama">
	  </div>
	  <div class="mb-3 mt-3">
		<label for="gender" class="form-label">Gender :</label>
        <div class="form-check">
			<input type="radio" class="form-check-input" id="laki" name="kodegender" value="L" checked>
			<label class="form-check-label" for="laki">Laki-laki</label>
		</div>
		<div class="form-check">
			<input type="radio" class="form-check-input" id="perempuan" name="kodegender" value="P">
			<label class="form-check-label" for="perempuan">perempuan</label>
		</div>
	  </div>
 	  <div class="mb-3 mt-3">
		<label for="alamat" class="form-label">Alamat:</label>
		<input type="text" class="form-control" id="alamat" name="alamat">
	  </div>  	  
      <div class="mb-3 mt-3">
	    <button class="btn btn-success mb-2" type="submit">Simpan</button>
        <button class="btn btn-success mb-2" type="reset">Batal</button>
      </div>
  </form>
</div>
@endsection

