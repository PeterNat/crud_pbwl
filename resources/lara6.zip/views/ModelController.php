<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Buku;
use App\Models\Anggota;
use App\Models\Peminjaman;

class ModelController extends Controller
{
	public function welcome(){
	return view('welcome');}

	// read buku
	public function buku(){
	$data_buku = Buku::all();
	return view('buku', compact('data_buku'));}

	//create buku
	public function createbuku(){
	return view('createbuku');}
	 
	//delete buku
	public function delbuku($id){
		$buku = Buku::find($id);
		$buku->delete();
		return redirect('/buku');}
		public function editbuku($id){
		$buku = Buku::find($id);
		return view('editbuku', compact('buku'));}
	   
	//edit buku
		public function updatebuku(Request $req, $id){
		$buku = Buku::find($id);
		$buku->judul = $req->judul;
		$buku->penulis = $req->penulis;
		$buku->penerbit = $req->penerbit;
		$buku->kodekategori = $req->kodekat;
		$buku->hargabuku = $req->harga;
		$buku->update();
		return redirect('/buku');}

	public function savebuku(Request $req){
	$buku = new Buku;
	$buku->judul = $req->judul;
	$buku->penulis = $req->penulis;
	$buku->penerbit = $req->penerbit;
	$buku->kodekategori = $req->kodekat;
	$buku->hargabuku = $req->harga;
	$buku->save();
	return redirect('/buku');}
		
	public function anggota(){
	$data_anggota = Anggota::all();
	return view('anggota', compact('data_anggota'));}
	// create data anggota
	public function createanggota(){
		return view('createanggota');}
		 
		public function saveanggota(Request $req){
		$anggota = new Anggota;
		$anggota->npm = $req->npm;
		$anggota->nama = $req->nama;
		$anggota->kodegender = $req->kodegender;
		$anggota->alamat = $req->alamat;
		
		$anggota->save();
		return redirect('/anggota');}
	//delete anggota
	public function delanggota($id){
		$anggota = Anggota::find($id);
		$anggota->delete();
		return redirect('/anggota');}
		public function editanggota($id){
		$anggota = Anggota::find($id);
		return view('editanggota', compact('anggota'));}
	   
	//edit anggota
		public function updateanggota(Request $req, $id){
		$anggota = Anggota::find($id);
		$anggota->npm = $req->npm;
		$anggota->nama = $req->nama;
		$anggota->kodegender = $req->kodegender;
		$anggota->alamat = $req->alamat;
		$anggota->update();
		return redirect('/anggota');}

	public function peminjaman(){
	$data_peminjaman = PEMINJAMAN::all();
	return view('peminjaman', compact('data_peminjaman'));}
}
