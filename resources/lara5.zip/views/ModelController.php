<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Buku;
use App\Models\Anggota;
use App\Models\Peminjaman;

class ModelController extends Controller
{
	public function welcome(){
	return view('welcome');}

	public function buku(){
	$data_buku = Buku::all();
	return view('buku', compact('data_buku'));}

	public function createbuku(){
	return view('createbuku');}
	 
	public function savebuku(Request $req){
	$buku = new Buku;
	$buku->judul = $req->judul;
	$buku->penulis = $req->penulis;
	$buku->penerbit = $req->penerbit;
	$buku->kodekategori = $req->kodekat;
	$buku->hargabuku = $req->harga;
	$buku->save();
	return redirect('/buku');}
		
	public function anggota(){
	$data_anggota = ANGGOTA::all();
	return view('anggota', compact('data_anggota'));}
	// create data buku
	public function createanggota(){
		return view('createanggota');}
		 
		public function saveanggota(Request $req){
		$anggota = new anggota;
		$anggota->npm = $req->npm;
		$anggota->nama = $req->nama;
		$anggota->kodegender = $req->kodegender;
		$anggota->alamat = $req->alamat;
		$anggota->save();
		return redirect('/anggota');}

	public function peminjaman(){
	$data_peminjaman = PEMINJAMAN::all();
	return view('peminjaman', compact('data_peminjaman'));}
}
