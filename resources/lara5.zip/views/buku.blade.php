@extends('master') 
@section('title', 'Data Buku') 

@section('content')
<div class="container mt-3">
  <h2>Data Buku</h2>  
  <p><a href="/createbuku">
  <button class="btn btn-success mb-2">Tambah Buku</button></a></p>  

  <table class="table table-bordered table-striped">
    <thead class="table-success">
      <tr style="text-align:center">
        <td>Id</td>
        <td>Judul</td>
	    <td>Penulis</td>
		<td>Penerbit</td>
		<td>Kode Kategori</td>		
		<td>Harga Buku</td>
		</tr>
	</thead> 

    <tbody>
	@foreach ($data_buku as $buku)
      <tr>
	    <td style="text-align:center">{{$buku->id}}</td>
        <td>{{$buku->judul}}</td>
		<td>{{$buku->penulis}}</td>	
		<td>{{$buku->penerbit}}</td>   			  
		<td style="text-align:center">{{$buku->kodekategori}}</td>	
		<td style="text-align:right">{{$buku->hargabuku}}</td>		
      </tr>
	@endforeach  
	</tbody>
  </table>
</div>  
@endsection

