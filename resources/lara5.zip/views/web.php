<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ModelController;

Route::get('/', [ModelController::class,'welcome']);

Route::get('/buku', [ModelController::class,'buku']);
Route::get('/createbuku', [ModelController::class,'createbuku']);
Route::post('/savebuku', [ModelController::class,'savebuku']);

Route::get('/anggota', [ModelController::class,'anggota']);
Route::get('/createanggota', [ModelController::class,'createanggota']);
Route::post('/saveanggota', [ModelController::class,'saveanggota']);
Route::get('/peminjaman', [ModelController::class,'peminjaman']);
